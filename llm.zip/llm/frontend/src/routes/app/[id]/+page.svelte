<div class="flex items-center justify-center h-full">
    <div class="flex flex-col justify-center items-center gap-5 p-15 glass rounded-[10%] relative">
        <div class="flex gap-2 absolute top-[80%] left-0 right-0 justify-center items-center">
            <div class="transition-all glass rounded-full p-5 px-15"></div>
        </div>
        <div>
            <div class="flex-1 font-light text-center text-primary">This page has not yet been fully developed.</div>
            <img src="../sloth.svg" alt="" class="float-right size-12" />
        </div>
        <div class="text-center text-primary">We don't think you have to be here.</div>
        <img src="../tree_of_knowledge.svg" alt="" class="size-40" />
    </div>
</div>
