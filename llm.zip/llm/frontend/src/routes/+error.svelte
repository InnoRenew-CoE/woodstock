<div class="flex flex-col justify-center items-center gap-5 h-full">
    <div>
        <div class="flex-1 font-light text-center text-gray-600">This page has not yet been fully deveoped.</div>
        <img src="../sloth.svg" alt="" class="float-right size-12 opacity-10" />
    </div>
    <div class="font-light text-center text-gray-400">I don't think you have to be here.</div>
    <img src="../tree_of_knowledge.svg" alt="" class="size-40" />
</div>
