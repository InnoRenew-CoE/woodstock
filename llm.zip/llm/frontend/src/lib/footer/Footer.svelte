<div class="bg-primary p-5 text-white">
    <div class="grid gap-2 items-center justify-center">
        <div id="partners" class="flex gap-3 h-[3rem] justify-center">
            <img src="../innorenew.svg" />
        </div>
    </div>
</div>
